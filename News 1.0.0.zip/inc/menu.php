<?php
echo '<a href="#">BOOTSTRAP</a> -
<a href="#">HTML</a> -
<a href="#">CSS</a> -
<a href="#">JAVASCRIPT</a> -
<a href="#">PHP</a>';
?>