   <br><br><br>
  <p>
<a href="/index.php" class="btn btn-primary btn-xs">الرئيـسية</a> 
<a href="index.php" class="btn btn-danger btn-xs">اتصل لنا</a> 
<a href="index.php" class="btn btn-warning btn-xs">اهدافنا</a>
 <a href="index.php" class="btn btn-info btn-xs">الخصوصية</a>
 <a href="/admin" class="btn btn-success btn-xs">مركز التحكم</a>

</p>

</div>
  </div>
            </div>        
        </div>
    </div>
        <footer>
<hr>
 <div class="container">
              عصر الواب &copy; 2018

            </div>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script> 
<script src="/bootstrap/js/bootstrap.min.js"></script>

        </footer>

        <br />
    </body>
</html>