<!DOCTYPE html>
<html dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>erorr pages</title>
      <meta name="viewport" content="width=device-width, initial-scale=1" />
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">

</head>
<body>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="page-header">
                        <h1>صفحة خاطئة</h1>
                    </div>
                    <div class="alert alert-danger fade in">
                        <p>فضلا توجة الى <a href="index.php" class="alert-link">الصفحة الرئيسية</a> اذا كنت تبحث عن صفحة صحيحة</p>
                    </div>
                </div>
            </div>        
        </div>
    </div>
</body>
</html>