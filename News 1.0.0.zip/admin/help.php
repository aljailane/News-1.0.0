<!DOCTYPE html>
<html dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>Create Record</title>
      <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    
</head>
<body>
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="page-header">
                        <h1>طريقة اضافة فيديو</h1>
                    </div>
                    <div class="alert alert-danger fade in">
                       
<div class="a5" align="center">
<br/><br/>
هذي طريقة اضافة اهداء فيديو
<br/>
اذهب الى موقع 
<a href="http://youtube.com">Youtube</a>
<br/><br/>
راح يفتح لك موقع الويب او تطبيق يوتيوب اذا فتح تطبيق اليوتيوب حط بحث عن الفيديو الذي تبي تهديه كما بالصوره 
في خيار البحث مثل رسالة حب 
<br/></div> 
<div align="center"><img src="http://wapkaimage.com/300336/300336464_9b799709db.png" alt="" /></div> 
<div class="a5" align="center"><big><br/><br/>
كما بالصوره وابحث راح تجيك مقاطع الفيديو بالقائمة افتح مقطع الفيديو اللي تبي تهدية كما بالصوره بعدها اضغط زر 
<span style="color: red;">مشاركة</span>
<br/></big></div> 
<div align="center"><img src="http://wapkaimage.com/300336/300336465_53b220b33a.png" alt="" /></div> 
<div class="a5" align="center"><big><br/>
الحين راح تظهر لك كما بالصور عدة برامج انته شو تسوي اعمل
<span style="color: red;">نسخ الرابط</span>
<br/></big></div> 
<div align="center"><img src="http://wapkaimage.com/300336/300336466_f812e6e0d1.png" alt="" /></div> 
<div class="a5" align="center"><big>اذن الحين صار عندنا الرابط ترا افهمني نحنا مابدنا الرابط كامل ركز معي نحنا بدنا الاحرف الاخيره من الرابط مثال الرابط كامل 
<br/><br/>
<span style="color: blue;">https://youtu.be/Zlo5OsBiuIA</span>
<br/><br/>

نحنا نبي هذي الحروف باللون الاحمر
<br/>
https://youtu.be/
<span style="color: red;">Zlo5OsBiuIA</span>
<br/><br/>
هذا فقط اللي راح نستخدمه بالاهدا بعد ماتاخذ هذا الا الاحرف تروح اضافة فيديو وتحطه وترسله وخلاص تم راح يظهر الفيديو كامل ومبروك
<br/><br/>
<span style="color: red;">Zlo5OsBiuIA</span>
</big></div> </p>
                    </div>
                </div>
            </div>        
        </div>
    </div>
</body>
</html>